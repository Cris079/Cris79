var button = document.querySelector("#btn");
button.onclick = function() {
  button.classList.add("animated", "pulse");
};